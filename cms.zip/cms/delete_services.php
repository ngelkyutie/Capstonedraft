<?php
session_start();
require 'db_connect.php';


if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}


if (!isset($_GET['id'])) {
    header('Location: admin_dashboard.php');
    exit;
}

$id = $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM services WHERE id = :id");
$stmt->bindParam(':id', $id);
$stmt->execute();
$service = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$service) {
   
    header('Location: admin_dashboard.php');
    exit;
}


$stmt = $conn->prepare("DELETE FROM services WHERE id = :id");
$stmt->bindParam(':id', $id);
$stmt->execute();


if (!empty($service['image_url']) && file_exists($service['image_url'])) {
    unlink($service['image_url']);
}


header('Location: admin_dashboard.php');
exit;
?>