<?php
session_start();
require 'db_connect.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin.php');
    exit;
}

// Fetch all services
$stmt = $conn->query("SELECT * FROM services");
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Admin Dashboard</h1>
        <nav>
            <ul>
                <li><a href="#">Dashboard</a></li>
                <li><a href="index.php">Manage Services</a></li>
                <li><a href="manage_appointment.php">Manage Appointments</a></li>
                <li><a href="add_patient.php">Add Patient</a></li>
                <li><a href="patient_list.php">Patient List</a></li>
               <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Services</h2>
            <table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($services as $service): ?>
        <tr>
            <td><?php echo $service['id']; ?></td>
            <td><?php echo htmlspecialchars($service['name']); ?></td>
            <td><?php echo htmlspecialchars($service['description']); ?></td>
            <td>PHP <?php echo number_format($service['price'], 2); ?></td>
            <td>
                <a href="edit_services.php?id=<?php echo $service['id']; ?>">Edit</a> |
                <a href="delete_service.php?id=<?php echo $service['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
            <a href="add_service.php">Add New Service</a>
        </section>

        <section>
    
                </thead>
                <tbody>
                    <?php

                    