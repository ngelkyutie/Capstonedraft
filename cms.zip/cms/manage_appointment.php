<?php
session_start();
require 'db_connect.php';

// Redirect to login if not authenticated as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

// Fetch all follow-ups
$stmt = $conn->query("SELECT follow_ups.*, patients.full_name as patient_name FROM follow_ups JOIN patients ON follow_ups.patient_id = patients.id ORDER BY follow_up_date DESC");
$follow_ups = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Appointments</title>
    <link rel="stylesheet" href="scheduling.css">
</head>
<body>
    <header>
        <h1>Manage Appointments</h1>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="schedule_follow_up.php">Schedule Follow-Up</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- List of Follow-Ups -->
        <section>
            <h2>Scheduled Follow-Ups</h2>
            <?php if (empty($follow_ups)): ?>
                <p>No follow-ups found.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Patient Name</th>
                            <th>Appointment Date</th>
                            <th>Procedure</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($follow_ups as $follow_up): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($follow_up['patient_name']); ?></td>
                            <td><?php echo date('M j, Y h:i A', strtotime($follow_up['follow_up_date'])); ?></td>
                            <td><?php echo htmlspecialchars($follow_up['notes']); ?></td>
                            <td>
                                <a href="edit_follow_up.php?id=<?php echo $follow_up['id']; ?>">Edit</a>
                                <a href="delete_follow_up.php?id=<?php echo $follow_up['id']; ?>" onclick="return confirm('Are you sure you want to delete this follow-up?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <p>&copy; 2023 JValera Dental Clinic. All rights reserved.</p>
    </footer>
</body>
</html>