<?php
session_start();
require 'db_connect.php';

// Redirect to login if not authenticated as a patient
if (!isset($_SESSION['patient_id'])) {
    header('Location: patient_login.php');
    exit;
}

// Fetch patient details
$stmt = $conn->prepare("SELECT * FROM patients WHERE id = :id");
$stmt->bindParam(':id', $_SESSION['patient_id']);
$stmt->execute();
$patient = $stmt->fetch(PDO::FETCH_ASSOC);


// Fetch patient follow-ups
$stmt = $conn->prepare("SELECT * FROM follow_ups WHERE patient_id = :patient_id ORDER BY follow_up_date DESC");
$stmt->bindParam(':patient_id', $_SESSION['patient_id']);
$stmt->execute();
$follow_ups = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard</title>
    <link rel="stylesheet" href="patient.css">
</head>
<body>
    <header>
        <h1>Welcome, <?php echo htmlspecialchars($patient['full_name']); ?></h1>
        <nav>
            <ul>
                <li><a href="patient_dashboard.php">Dashboard</a></li>
                <li><a href="logout_patient.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
    

        <!-- List of Follow-Ups -->
        <section>
            <h2>Your Appointment Schedule</h2>
            <?php if (empty($follow_ups)): ?>
                <p>No follow-ups found.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Appointment Date and Time</th>
                            <th>Procedure</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($follow_ups as $follow_up): ?>
                        <tr>
                            <td><?php echo date('M j, Y h:i A', strtotime($follow_up['follow_up_date'])); ?></td>
                            <td><?php echo htmlspecialchars($follow_up['notes']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <p>&copy; 2023 JValera Dental Clinic. All rights reserved.</p>
    </footer>
</body>
</html>