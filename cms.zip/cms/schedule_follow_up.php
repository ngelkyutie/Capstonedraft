<?php
session_start();
require 'db_connect.php';

// Redirect to login if not authenticated as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

// Handle form submission for scheduling a follow-up
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['schedule_follow_up'])) {
    $patient_id = trim($_POST['patient_id']);
    $follow_up_date = trim($_POST['follow_up_date']);
    $notes = trim($_POST['notes']);

    // Insert the follow-up into the database
    $stmt = $conn->prepare("INSERT INTO follow_ups (patient_id, follow_up_date, notes) VALUES (:patient_id, :follow_up_date, :notes)");
    $stmt->bindParam(':patient_id', $patient_id);
    $stmt->bindParam(':follow_up_date', $follow_up_date);
    $stmt->bindParam(':notes', $notes);
    $stmt->execute();

    // Redirect to the manage appointments page after scheduling
    header('Location: manage_appointment.php');
    exit;
}

// Fetch all patients
$stmt = $conn->query("SELECT * FROM patients");
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule Follow-Up</title>
    <link rel="stylesheet" href="scheduling.css">
</head>
<body>
    <header>
        <h1>Schedule Follow-Up</h1>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="manage_appointment.php">Manage Appointments</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- Schedule Follow-Up Form -->
        <section>
            <h2>Schedule Appointment</h2>
            <form method="POST" action="schedule_follow_up.php">
                <div>
                    <label for="patient_id">Select Patient:</label>
                    <select name="patient_id" id="patient_id" required>
                        <option value="">Choose a patient</option>
                        <?php foreach ($patients as $patient): ?>
                            <option value="<?php echo $patient['id']; ?>"><?php echo htmlspecialchars($patient['full_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label for="follow_up_date">Follow-Up Date & Time:</label>
                    <input type="datetime-local" name="follow_up_date" id="follow_up_date" required>
                </div>
                <div>
                    <label for="notes">Notes:</label>
                    <textarea name="notes" id="notes"></textarea>
                </div>
                <div>
                    <button type="submit" name="schedule_follow_up">Schedule Follow-Up</button>
                </div>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2023 JValera Dental Clinic. All rights reserved.</p>
    </footer>
</body>
</html>